#pragma once

#if F_CPU == 8000000
// for 1us clock duration -- prescaler 8 @ 8MHz
#else
 #error (currently) unsupported F_CPU clock frequency!
#endif

//
// nRF control pins
//

#define CE_PORT		D              //Arduino Mini Pro 7
#define CE_PIN		7              

// nrf/uC SPI pins

#define CSN_PORT	B              //Arduino Mini Pro 10
#define CSN_PIN		2

#define MOSI_PORT	B              //Arduino Mini Pro 11
#define MOSI_PIN	3

#define MISO_PORT	B              //Arduino Mini Pro 12
#define MISO_PIN	4

#define SCK_PORT	B              //Arduino Mini Pro 13
#define SCK_PIN		5


