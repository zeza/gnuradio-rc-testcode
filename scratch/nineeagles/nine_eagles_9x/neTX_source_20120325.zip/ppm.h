//
// ppm.h - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//

#pragma once

// my er9x setup
#define CH_THR		2
#define CH_RUD		0
#define CH_ELE		1
#define CH_AIL		3

/*
// got these from the net, I haven't checked them

// JR
#define CH_THR		0
#define CH_RUD		3
#define CH_ELE		2
#define CH_AIL		1

// Futaba
#define CH_THR		2
#define CH_RUD		3
#define CH_ELE		1
#define CH_AIL		0
*/

// The minimal and maximal duration of one channel of the PPM pulse
// train in microseconds. For some TXs this range is 800us - 2200us.
#define MIN_CHANNEL_DUR		1000
#define MAX_CHANNEL_DUR		2000

// enable/disable input capture interrupt
// which turns the PPM decoder on or off
#define PPM_On()		SetBit(TIMSK1, ICIE1)
#define PPM_Off()		ClrBit(TIMSK1, ICIE1)

// returns != 0 if the PPM decoder is on
#define IsPPM_On()		((TIMSK1 & _BV(ICIE1)) != 0)

// for 0.5us timer clock duration -- prescaler 8 @ 16MHz
#define clock2us(clk)	((clk)/2)
#define us2clock(us)	((us)*2)

// max number of channels the PPM decoder can process
#define MAX_CHANNELS	12

extern volatile uint16_t PPM_frame[MAX_CHANNELS];	// contains channel durations of the current frame
extern volatile uint8_t PPM_decoded;				// counts the number of decoded PPM packets

void PPM_Init(void);
void PPM_LED_Driver(void);
