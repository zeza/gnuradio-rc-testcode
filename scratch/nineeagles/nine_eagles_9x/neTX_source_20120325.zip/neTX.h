//
// neTX.h - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//

#pragma once

// this is the data packet that is used for information exchange between the TX and the RX
typedef struct
{
	uint8_t		throttle;	// stick position
	uint8_t		rudder;		// the range of these is 0 - 0x7f
	uint8_t		elevator;	// in normal TX operation (when command == 0x55)
	uint8_t		aileron;
	
	uint8_t		command;	// 0x55 for sticks data and bind response
							// 0xAA for bind packet
							// 0xDA for subtrim packet

	uint16_t	tx_id;		// id of the TX
							// Merlin 90: 0xA0FF
							// SoloPro :  0xF04A
} nePacket_t;

// The ID of this TX module. This can be any 16 bit number or an ID of an existing TX
#define TX_ID	0xA04A

// This functions sets the RX and TX addresses and initializes the nRF24L01 chip
// with all the general settings. It also finds a free channel like a stock TX does
void TX_Init(void);

// Performs binding with the TX_ID defined above. It will try to send bind
// packets to any listening RX.
// It will return only after it receives successful confirmation of binding
void TX_Bind(void);

// Runs the copy TX_ID procedure. It does this by switching to RX mode and waiting to
// hear from a stock TX. If it hears one, it extracts it's ID from the data and then
// uses that as it's own TX ID. In other words, it impersonates your stock TX
// so that it becomes unnecessary to bind the heli every time you go back and forth
// between using the stock TX and the TX module.
// The device also saves that impersonated TX ID into EEPROM and keeps on using that
// until a normal bind procedure is started, or a new copy TX ID procedure is done
// with a third stock TX
void TX_CopyTX_ID(void);

// sends a packet of stick information to the RX. this function should be called once
// every ~3ms. the function implements the 'channel hopping' like the stock TX does
void TX_Send(nePacket_t* pPacket);
