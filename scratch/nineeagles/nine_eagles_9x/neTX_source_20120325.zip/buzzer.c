//
// buzzer.c - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//

#include <avr/io.h>

#include "hw_setup.h"
#include "utils.h"
#include "buzzer.h"

// BuzzSequence holds the on and off durations of the buzzer.
// These are in Timer1 overflow counts (32.768ms)
// The number of active elements of this array is stored in BuzzSeqLen

volatile const uint8_t* BuzzSequence;
volatile uint8_t BuzzSeqLen = 0;
volatile uint8_t BuzzFlags = 0;

#define BUZZ_ON_DUTY_CYCLE		0x80
#define BUZZ_OFF_DUTY_CYCLE		0

void BuzzInit(void)
{
	SetBit(DDR(BUZZER_PORT), BUZZER_BIT);	// output
	ClrBit(PORT(BUZZER_PORT), BUZZER_BIT);	// off

	// init the buzzer PWM
	TCCR0A = _BV(COM0A1)	// clear OC0A on up count, set on down
			| _BV(WGM00);	// phase correct PWM, TOP is 0xff

	OCR0A = BUZZ_OFF_DUTY_CYCLE;
	
	TCCR0B = _BV(CS02) | _BV(CS00);		// prescaler 1024
}

void BuzzStart(const uint8_t* seq, const uint8_t seqLen, const uint8_t should_loop)
{
	HeartbeatOff();
	
	if (should_loop)
		BuzzLoop();
	else
		BuzzOnce();

	// force a reset in BuzzDriver()
	SetBit(BuzzFlags, BUZZ_FLAG_RESET);
	
	BuzzSequence = seq;
	BuzzSeqLen = seqLen;

	// start the buzzer
	SetBit(BuzzFlags, BUZZ_FLAG_IS_ON);
	
	HeartbeatOn();
}

void BuzzDriver(void)
{
	if (IsBuzzOn()  &&  BuzzSeqLen != 0)
	{
		static uint8_t seq_pos = 0;	// the position in the sequence
		static uint8_t seq_cnt = 0;	// the counter on a specific position

		// do we have a reset request from BuzzStart() ?
		if ((BuzzFlags & _BV(BUZZ_FLAG_RESET)) != 0)
		{
			seq_pos = seq_cnt = 0;	// the position in the sequence
			ClrBit(BuzzFlags, BUZZ_FLAG_RESET);
		}

		// on the first call for this element turn the
		// buzzer on/off by changing the PWM duty cycle
		if (seq_cnt == 0)
		{
			if (seq_pos & 1)	// odd?
				OCR0A = BUZZ_OFF_DUTY_CYCLE;
			else
				OCR0A = BUZZ_ON_DUTY_CYCLE;
		}

		// has the current element's duration elapsed?
		if (seq_cnt >= BuzzSequence[seq_pos])
		{
			seq_cnt = 0;
			seq_pos++;		// next element

			// last element?
			if (seq_pos == BuzzSeqLen)
			{
				seq_pos = 0;		// reset element counter

				// no looping?
				if (!IsBuzzLooping())
				{
					OCR0A = BUZZ_OFF_DUTY_CYCLE;
					
					// turn the buzzer off
					ClrBit(BuzzFlags, BUZZ_FLAG_IS_ON);
				}
			}
		} else {
			++seq_cnt;
		}
	} else {
		OCR0A = BUZZ_OFF_DUTY_CYCLE;
	}
}

void BuzzStop(void)
{
	HeartbeatOff();
	ClrBit(BuzzFlags, BUZZ_FLAG_IS_ON);
	HeartbeatOn();
}

void BuzzLoop(void)
{
	HeartbeatOff();
	SetBit(BuzzFlags, BUZZ_FLAG_LOOP);
	HeartbeatOn();
}

void BuzzOnce(void)
{
	HeartbeatOff();
	ClrBit(BuzzFlags, BUZZ_FLAG_LOOP);
	HeartbeatOn();
}
