//
// hw_setup.h - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//

#pragma once

// this file contains the definitions of
// all the uC pins used by the project

//
// nRF (SPI) module pins
//

#define NRF_IRQ_PORT	C
#define NRF_IRQ_BIT		0

#define NRF_CE_PORT		B
#define NRF_CE_BIT		1

// the 3.3v regulator on/off pin
#define NRF_PWR_PORT	D
#define NRF_PWR_BIT		7

// this must be the SS pin of the SPI
#define NRF_CSN_PORT	B
#define NRF_CSN_BIT		2

#define NRF_MOSI_PORT	B
#define NRF_MOSI_BIT	3

#define NRF_MISO_PORT	B
#define NRF_MISO_BIT	4

#define NRF_SCK_PORT	B
#define NRF_SCK_BIT		5


// the signal LEDs
#define PPM_SIGNAL_LED_PORT		D
#define PPM_SIGNAL_LED_BIT		5

#define BIND_LED_PORT			D
#define BIND_LED_BIT			3

#define COPY_TX_ID_LED_PORT		C
#define COPY_TX_ID_LED_BIT		1


// PPM input port/pin
// this MUST be the ICP pin of the AVR
#define PPM_IN_PORT				B
#define PPM_IN_BIT				0


// the buttons
#define BIND_BTN_PORT			C
#define BIND_BTN_BIT			4

#define COPY_TX_ID_BTN_PORT		C
#define COPY_TX_ID_BTN_BIT		3


// the buzzer (must be on OC0A)
#define BUZZER_PORT				D
#define BUZZER_BIT				6


// V-USB -- not used by neTX, but we define it here to avoid
// "Device not recognized" errors if plugged in to USB

#define VUSB_DMINUS_PORT		D
#define VUSB_DMINUS_BIT			4

#define VUSB_DPLUS_PORT			D
#define VUSB_DPLUS_BIT			2

#define VUSB_DISC_PORT			C
#define VUSB_DISC_BIT			2
