//
// avr_serial.h - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//
 
#pragma once

void init_serial(void);
uint8_t serial_getchar(void);
