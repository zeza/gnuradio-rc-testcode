//
// ppm.c - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//

#include <avr/io.h>
#include <avr/interrupt.h>

#include "hw_setup.h"
#include "utils.h"
#include "ppm.h"

volatile uint16_t PPM_frame[MAX_CHANNELS];	// contains channel durations of the current frame
volatile uint8_t PPM_decoded = 0;			// counts the number of decoded PPM packets

uint8_t last_ppm_channel = 0;				// index of the last channel the decoder needs

void PPM_Init(void)
{
	// PPM in
	ClrBit(DDR(PPM_IN_PORT), PPM_IN_BIT);	// input
	SetBit(PORT(PPM_IN_PORT), PPM_IN_BIT);	// pull-up

	// calc the index of last channel the PPM decoder needs. 
	// this way we can send a packet as soon as we get the last
	// relevant channel from the PPM train. there is no need to
	// wait for the entire PPM frame to complete. helps with the lag a little :D
	last_ppm_channel = CH_THR > CH_RUD ? CH_THR : CH_RUD;
	if (last_ppm_channel < CH_ELE)		last_ppm_channel = CH_ELE;
	if (last_ppm_channel < CH_AIL)		last_ppm_channel = CH_AIL;

	// setup the input capture timer for the PPM decoder
	TCCR1A = 0;
	TCCR1B = _BV(ICNC1) | _BV(CS11);	// ICNC1 - noise canceler,
										// falling edge (ICES1)
										// @12MHz F_CPU - 8 prescaler 0.667us resolution
										// @16MHz F_CPU - 8 prescaler 0.5us resolution

	HeartbeatOn();		// enable the timer overflow interrupt
	
	// the input capture interrupt is stil disabled
	// we enable it later with the PPM_On() macro
}

// Input capture interrupt on Timer1. This captures the durations between the falling edges of
// the PPM signal that we receive from the TX. The function stores the number of timer clocks
// in the frame[] array. main() converts these using clock2ne() into the values that the nine
// eagles protocol needs
ISR(TIMER1_CAPT_vect)
{
	static uint8_t ch_cnt = 0;

	uint16_t curr_cnt, diff;
	static uint16_t last_cnt = 0;

	// calculate the difference since last interrupt
	curr_cnt = ICR1;
	diff = curr_cnt - last_cnt;
	last_cnt = curr_cnt;

	if (diff < us2clock(2300))
	{
		if (ch_cnt < MAX_CHANNELS)
			PPM_frame[ch_cnt++] = diff;

		// was this the last relevant channel?
		if (ch_cnt > last_ppm_channel)
		{
			// Increase the PPM packet counter. This signals the main loop that we
			// have all the relevant channels of a PPM frame
			++PPM_decoded;
		}
	} else {
		// on gap reset the channel counter
		ch_cnt = 0;
	}
}

// takes care of the PPM indicator LED
void PPM_LED_Driver(void)
{
	// switches the PPM signal LED on/off
	static uint8_t last_ppm_decoded = 0, led_cnt = 0;
	
	if (IsPPM_On())
	{
		// no new PPM decodes since last overflow?
		if (last_ppm_decoded == PPM_decoded)
		{
			ClrBit(PORT(PPM_SIGNAL_LED_PORT), PPM_SIGNAL_LED_BIT);
		} else {
			// the LED
			led_cnt++;
			
			if (led_cnt == 0x30)	led_cnt = 0;

			if (led_cnt < 2)
				SetBit(PORT(PPM_SIGNAL_LED_PORT), PPM_SIGNAL_LED_BIT);
			else
				ClrBit(PORT(PPM_SIGNAL_LED_PORT), PPM_SIGNAL_LED_BIT);
		}

		last_ppm_decoded = PPM_decoded;
	}
}
