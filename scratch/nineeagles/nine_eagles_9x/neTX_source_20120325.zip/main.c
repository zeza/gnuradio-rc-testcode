//
// main.c - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//

#include <stdio.h>
#include <string.h>

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "hw_setup.h"
#include "avr_serial.h"
#include "utils.h"
#include "buzzer.h"
#include "neTX.h"
#include "ppm.h"

#include "nRF24L01.h"

// Overflow interrupt on Timer1. Called every 32.768ms @ 16MHz
// This is used as a sort of system hearbeat. It takes care of the
// PPM LED and calls the buzzer driver
// Timer1's main use is decoding the PPM signal, this is it's
// secondary function
ISR(TIMER1_OVF_vect, ISR_NOBLOCK)
{
	PPM_LED_Driver();

	BuzzDriver();
}

void InitMiscHW(void)
{
	// the LEDs as output
	SetBit(DDR(PPM_SIGNAL_LED_PORT), PPM_SIGNAL_LED_BIT);
	ClrBit(PORT(PPM_SIGNAL_LED_PORT), PPM_SIGNAL_LED_BIT);

	SetBit(DDR(COPY_TX_ID_LED_PORT), COPY_TX_ID_LED_BIT);
	ClrBit(PORT(COPY_TX_ID_LED_PORT), COPY_TX_ID_LED_BIT);

	SetBit(DDR(BIND_LED_PORT), BIND_LED_BIT);
	ClrBit(PORT(BIND_LED_PORT), BIND_LED_BIT);

	// the buttons: inputs with pull-ups
	ClrBit(DDR(BIND_BTN_PORT), BIND_BTN_BIT);
	SetBit(PORT(BIND_BTN_PORT), BIND_BTN_BIT);

	ClrBit(DDR(COPY_TX_ID_BTN_PORT), COPY_TX_ID_BTN_BIT);
	SetBit(PORT(COPY_TX_ID_BTN_PORT), COPY_TX_ID_BTN_BIT);
	
	// pull down the V-USB pull-up to make sure we're disconnected
	// from USB on the off change that the USB cable is plugged in
	SetBit(DDR(VUSB_DISC_PORT), VUSB_DISC_BIT);
	ClrBit(PORT(VUSB_DISC_PORT), VUSB_DISC_BIT);
}


// Converts the PPM duration in timer ticks into the number needed by the RX.
// it executes in about 20us on a 16MHz clock
static uint8_t clock2ne(uint16_t clk)
{
	// enforce the range
	if (clk < us2clock(MIN_CHANNEL_DUR))		clk = us2clock(MIN_CHANNEL_DUR);
	if (clk > us2clock(MAX_CHANNEL_DUR))		clk = us2clock(MAX_CHANNEL_DUR);

	// we're performing the calculation multiplied by 10 to increase precision and
	// avoid the slow floating point math
	const uint16_t clk_range = us2clock(MAX_CHANNEL_DUR) - us2clock(MIN_CHANNEL_DUR);
	const uint16_t clk2ne_ratio = (clk_range * 10) / 0x7f;

	uint8_t ret_val = ((clk - us2clock(MIN_CHANNEL_DUR)) * 10) / clk2ne_ratio;

	if (ret_val > 0x7f)
		ret_val = 0x7f;

	return ret_val;
}

/*
void delay_ms(uint16_t ms)
{
	while (ms != 0)
	{
		_delay_ms(1);
		--ms;
	}
}
*/

// __attribute__((noreturn))
void main(void)
{
	init_serial();	// UART is currently only used for debugging
	InitMiscHW();	// init the LEDs, buttons and the V-USB disc
	BuzzInit();		// initialize the buzzer
	PPM_Init();		// initilize on the PPM decoder, but don't turn it on yet

	sei();			// interrupts on (needed by the PPM decode and the buzzer)

	TX_Init();		// inits the nRF to work with neTX

	// Do the binding or the copy TX ID if either of the respective buttons
	// are pressed
	if ((PIN(BIND_BTN_PORT) & _BV(BIND_BTN_BIT)) == 0)
		TX_Bind();
	else if ((PIN(COPY_TX_ID_BTN_PORT) & _BV(COPY_TX_ID_BTN_BIT)) == 0)
		TX_CopyTX_ID();
		
	PPM_On();		// start the input capture interrup -- PPM decoder
	
	// the main send loop
	nePacket_t nePacket;
	uint8_t last_ppm_decoded = 0;

	// nePacket.throttle	= 0;
	// nePacket.rudder		= 0x40;
	// nePacket.aileron	= 0x40;
	// nePacket.elevator	= 0x40;
	
	// This one counts the number of loop iterations between PPM frames.
	// If this counter gets too high (~20) this means we haven't had a
	// valid PPM frame for too long, and we should stop sending packets
	uint8_t loop_cnt = 0xff;
	const uint8_t SEND_UNTIL_LOOP_CNT = 20;
	
	for (;;)
	{
		// do we have a fresh PPM frame?
		if (last_ppm_decoded != PPM_decoded)
		{
			nePacket.throttle	= clock2ne(PPM_frame[CH_THR]);
			nePacket.rudder		= 0x80 - clock2ne(PPM_frame[CH_RUD]);
			nePacket.aileron	= clock2ne(PPM_frame[CH_AIL]);
			nePacket.elevator	= clock2ne(PPM_frame[CH_ELE]);

			//printf("0x%02x 0x%02x 0x%02x 0x%02x\r", (uint16_t) nePacket.throttle,
			//										(uint16_t) nePacket.rudder,
			//										(uint16_t) nePacket.aileron,
			//										(uint16_t) nePacket.elevator);
			
			last_ppm_decoded = PPM_decoded;
			
			loop_cnt = 0;		// reset the counter
		} else {
			// increase the counter
			if (loop_cnt < 0xff)
				++loop_cnt;
		}

		if (loop_cnt < SEND_UNTIL_LOOP_CNT)
			TX_Send(&nePacket);

		// wait a little
		_delay_ms(3);
	}
}
