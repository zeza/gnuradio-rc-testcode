//
// neTX.c - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//

#include <stdio.h>
#include <string.h>

#include <avr/io.h>
#include <avr/eeprom.h>
#include <util/delay.h>

#include "hw_setup.h"
#include "neTX.h"
#include "utils.h"
#include "buzzer.h"
#include "nRF24L01.h"

// the length of the Nine Eagles data packet
#define PACKET_LENGTH	7

// the last channel to cycle to in loops when looking for a packet
#define LAST_CHANNEL	69

// the storage for the tx ids in the EEPROM
typedef struct 
{
	// on a valid EEPROM  Saved_TX_ID == ~Check_TX_ID
	uint16_t	Saved_TX_ID;
	uint16_t	Check_TX_ID;
} TX_ID_store_t;

TX_ID_store_t EEMEM TX_ID_store;

uint16_t	neActiveTX_ID = TX_ID;	// the TX ID we're sending in each packet

uint8_t		neChannel = 10;
uint8_t		neChannelOffset = 0;

// communication address
const uint8_t NEAddr[] = {0x34, 0x43, 0x10, 0x10, 0x01};

// the buzzer sequence(s)
const uint8_t bindSeq[] = {2, 2, 2, 50, 25};

// reads the copy TX ID stored in EEPEROM
// returns 1 on success, 0 otherwise
static uint8_t ReadTX_ID(uint16_t* ptx_id)
{
	TX_ID_store_t id_store;
	eeprom_read_block(&id_store, &TX_ID_store, sizeof(id_store));
	
	// is this a valid TX ID?
	if (id_store.Saved_TX_ID == ~id_store.Check_TX_ID)
	{
		*ptx_id = id_store.Saved_TX_ID;
		return 1;
	}

	return 0;
}

// saves a copied TX ID to EEPROM
static void SaveTX_ID(uint16_t tx_id)
{
	// don't write the ID if it is already in the EEPROM
	uint16_t check_tx_id;
	if (ReadTX_ID(&check_tx_id)  &&  check_tx_id == tx_id)
		return;
		
	// save the TX ID into EEPROM
	TX_ID_store_t id_store;
	id_store.Saved_TX_ID = tx_id;
	id_store.Check_TX_ID = ~tx_id;
	
	eeprom_write_block(&id_store, &TX_ID_store, sizeof(id_store));
}

// clears the TX ID from EEPROM
static void ClearTX_ID()
{
	// don't clear the ID if the one in EEPROM is already invalid
	uint16_t check_tx_id;
	if (!ReadTX_ID(&check_tx_id))
		return;

	// save an invalid TX ID into EEPROM
	TX_ID_store_t id_store;
	id_store.Saved_TX_ID = 0;
	id_store.Check_TX_ID = 0;
	
	eeprom_write_block(&id_store, &TX_ID_store, sizeof(id_store));
}

void TX_Init(void)
{
	nRF_Init();

	nRF_WriteAddrReg(TX_ADDR, NEAddr, 5);	// write the address
	nRF_WriteAddrReg(RX_ADDR_P0, NEAddr, 5);
	
#ifdef NRF_CHECK_MODULE

	nRF_data[1] = 0;
	nRF_data[2] = 0;
	nRF_data[3] = 0;
	nRF_data[4] = 0;
	nRF_data[5] = 0;
	
	nRF_ReadAddrReg(TX_ADDR, 5);	// read the address back
	
	// compare
	if (memcmp(nRF_data + 1, NEAddr, 5) != 0)
	{
		// it doesn't match -- all hell breaks loose
		
		// buzzer
		const uint8_t panicSeq[] = {6, 6};
		BuzzStart(panicSeq, 2, 1);
		
		// toggle all the LEDs forever
		for (;;)
		{
			TogBit(PORT(PPM_SIGNAL_LED_PORT), PPM_SIGNAL_LED_BIT);
			TogBit(PORT(BIND_LED_PORT), BIND_LED_BIT);
			TogBit(PORT(COPY_TX_ID_LED_PORT), COPY_TX_ID_LED_BIT);
			
			_delay_ms(500);
		}
	}

#endif	// NRF_CHECK_MODULE
	
	nRF_WriteReg(EN_AA, vENAA_P0);			// enable auto acknoledge
	nRF_WriteReg(SETUP_RETR, 0);			// ARD=250us, ARC=disabled
	nRF_WriteReg(RF_SETUP, vRF_DR_250KBPS | vLNA_HCURR | vRF_PWR_0DBM);	// data rate, output power and noise cancel
	nRF_WriteReg(RX_PW_P0, PACKET_LENGTH);	// RX payload length
	nRF_WriteReg(EN_RXADDR, vERX_P0);		// enable RX address
	nRF_WriteReg(STATUS, vRX_DR | vTX_DS | vMAX_RT);	// reset the IRQ flags

	// Read the copied TX ID from the EEPROM.
	// The function sets neActiveTX_ID only if there is a valid TX ID in the EEPROM
	ReadTX_ID(&neActiveTX_ID);
	
	//
	// find a free channel sequence
	//
	
	uint8_t channelFound = 0;
	neChannelOffset = 0;
	do {
		nRF_WriteReg(RF_CH, neChannel + neChannelOffset);				// set the channel
		nRF_WriteReg(CONFIG, vEN_CRC | vCRCO | vPWR_UP | vPRIM_RX);		// switch to RX mode
		
		nRF_CE_hi();		// power up the transceiver
		
		channelFound = 1;
		uint8_t cnt;
		for (cnt = 0; cnt < 30; cnt++)
		{
			// wait a little
			_delay_ms(2);
			
			// check if the nRF has something to tell us
			if ((PIN(NRF_IRQ_PORT) & _BV(NRF_IRQ_BIT)) == 0)
			{
				nRF_NOP();		// read STATUS register

				if ((nRF_data[0] & vRX_DR) != 0)	// RX data?
				{
					nRF_CE_lo();		// power down

					nRF_WriteReg(STATUS, vRX_DR);	// reset RX_DR
				
					// we don't really care what data we got, so just flush the RX buffer
					nRF_FlushRX();
					
					// we received data on this channel, so try the next one
					channelFound = 0;

					// change the channel
					if (channelFound == 0)
					{
						++neChannelOffset;
						if (neChannelOffset == 20)
							neChannelOffset = 0;
					}
					
					break;	// try next channel
				}
			}
		}

	} while (channelFound == 0);

	// power down the transceiver
	nRF_CE_lo();
	
	// we have to wait before we can switch to TX mode
	_delay_us(130);
}

void TX_Send(nePacket_t* pPacket)
{
	// clear the TX buffer
	nRF_FlushTX();

	// reset the status flag
	nRF_WriteReg(STATUS, vMAX_RT);

	// cycle the channels
	if (neChannel == 10)
		neChannel = 30;
	else if (neChannel == 30)
		neChannel = 50;
	else
		neChannel = 10;
	
	nRF_WriteReg(RF_CH, neChannel + neChannelOffset);

	nRF_WriteReg(CONFIG, vEN_CRC | vCRCO | vPWR_UP);	// TX mode
	
	// set the TX ID and the command byte
	pPacket->tx_id = neActiveTX_ID;
	pPacket->command = 0x55;
	
	// send a fresh packet to the nRF
	nRF_WriteTxPayload((uint8_t*) pPacket, PACKET_LENGTH);

	nRF_CE_hi();		// power up the transceiver
	
	// wait for MAX_RT for max 1ms
	uint8_t cnt = 0;
	while (cnt < 100  &&  (PIN(NRF_IRQ_PORT) & _BV(NRF_IRQ_BIT)) != 0)
	{
		_delay_us(10);
		++cnt;
	}

	nRF_CE_lo();		// power down the transceiver

	nRF_FlushTX();
	nRF_WriteReg(STATUS, vMAX_RT);	// reset MAX_RT flag
}

void TX_Bind(void)
{
	BuzzStart(bindSeq + 2, 2, 1);	// start buzzing
	
	// turn on the bind LED
	SetBit(PORT(BIND_LED_PORT), BIND_LED_BIT);

	// clear any saved TX ID
	ClearTX_ID();
	
	// set the channel
	nRF_WriteReg(RF_CH, neChannel + neChannelOffset);

	// reset the IRQ flags
	nRF_WriteReg(STATUS, vRX_DR | vTX_DS | vMAX_RT);
	
	// init the binding message
	nePacket_t bindPacket;

	bindPacket.throttle	= 0xAA;
	bindPacket.rudder	= 0xAA;
	bindPacket.elevator	= 0xAA;
	bindPacket.aileron	= 0xAA;

	bindPacket.command	= 0xAA;
	bindPacket.tx_id	= TX_ID;
	
	uint8_t is_bound = 0;
	uint8_t led_cnt = 0;
	do {
		// the LED
		led_cnt++;

		if (led_cnt == 0x80)
			led_cnt = 0;

		if (led_cnt < 0x10)
			SetBit(PORT(BIND_LED_PORT), BIND_LED_BIT);
		else
			ClrBit(PORT(BIND_LED_PORT), BIND_LED_BIT);
		
		// power down the transceiver
		nRF_CE_lo();
	
		// clear the buffers
		nRF_FlushTX();
		nRF_FlushRX();
	
		// send the bind packet
		nRF_WriteTxPayload((uint8_t*) &bindPacket, PACKET_LENGTH);	// send the bind packet
		nRF_WriteReg(CONFIG, vEN_CRC | vCRCO | vPWR_UP);			// switch to TX mode

		_delay_us(130);		// delay for the nRF RX/TX setting transition
		
		nRF_CE_hi();		// power up the transceiver
		
		// wait for the packet to be sent
		loop_until_bit_is_clear(PIN(NRF_IRQ_PORT), NRF_IRQ_BIT);
		
		nRF_CE_lo();		// power down the transceiver
		
		nRF_WriteReg(STATUS, vRX_DR | vTX_DS | vMAX_RT);	// reset the flag(s)
		
		_delay_us(130);		// we have to wait for RX resettle to switch to RX mode
		
		// switch to RX mode
		nRF_WriteReg(CONFIG, vEN_CRC | vCRCO | vPWR_UP | vPRIM_RX);

		nRF_CE_hi();		// power up the transceiver

		// wait ~2ms for a response
		uint16_t cnt;
		for (cnt = 0; cnt < 200  &&  !is_bound; ++cnt)
		{
			// check for an IRQ from the nRF
			if ((PIN(NRF_IRQ_PORT) & _BV(NRF_IRQ_BIT)) == 0)
			{
				// we have something happening on the nRF
				nRF_NOP();		// read STATUS register

				// do we have a packet?
				if ((nRF_data[0] & vRX_DR) != 0)
				{
					// read the packet contents
					nRF_ReadRxPayload(PACKET_LENGTH);

					// is this the bind response packet?
					if (strncmp("\x55\x55\x55\x55\x55", (char*) (nRF_data + 1), 5) == 0
							&&  *((uint16_t*)(nRF_data + 6)) == TX_ID)
					{
						// exit the bind loop
						is_bound = 1;
					}
				}

				nRF_WriteReg(STATUS, vRX_DR | vTX_DS | vMAX_RT);	// reset the status flags

			} else {
				// wait a little
				_delay_us(10);
			}
		}
		
	} while (!is_bound);

	BuzzStart(bindSeq + 4, 1, 0);	// do one long buzz
	
	nRF_CE_lo();		// power down the transceiver

	nRF_FlushTX();		// clear the buffers
	nRF_FlushRX();
	
	_delay_us(130);		// wait 130us for the RX<->TX mode transition

	// turn off the bind LED
	ClrBit(PORT(BIND_LED_PORT), BIND_LED_BIT);
}

void TX_CopyTX_ID(void)
{
	BuzzStart(bindSeq, 4, 1);	// start buzzing
	
	// turn on the LED
	SetBit(PORT(COPY_TX_ID_LED_PORT), COPY_TX_ID_LED_BIT);
	
	nRF_WriteReg(CONFIG, vEN_CRC | vCRCO | vPWR_UP | vPRIM_RX);		// RX mode
	
	uint8_t locNeChannel = 10;
	uint8_t tx_id_found = 0, cnt, led_cnt = 0;
	do {
		nRF_WriteReg(RF_CH, locNeChannel);		// set the channel
		
		nRF_CE_hi();		// power up the transceiver
		
		for (cnt = 0; cnt < 60; cnt++)
		{
			// the LED
			led_cnt++;

			if (led_cnt == 0xff)
				led_cnt = 0;

			if (led_cnt < 0x20)
				SetBit(PORT(COPY_TX_ID_LED_PORT), COPY_TX_ID_LED_BIT);
			else
				ClrBit(PORT(COPY_TX_ID_LED_PORT), COPY_TX_ID_LED_BIT);
		
			// wait a little
			_delay_ms(1);
			
			// check if the nRF has something to tell us
			if ((PIN(NRF_IRQ_PORT) & _BV(NRF_IRQ_BIT)) == 0)
			{
				nRF_NOP();		// read STATUS register

				if ((nRF_data[0] & vRX_DR) != 0)	// RX data?
				{
					nRF_CE_lo();		// power down

					nRF_WriteReg(STATUS, vRX_DR);	// reset RX_DR
				
					// read the packet
					nRF_ReadRxPayload(7);
					
					// is this a normal packet?
					if (nRF_data[5] == 0x55)
					{
						// yes, copy the ID
						neActiveTX_ID = *((uint16_t*)(nRF_data + 6));
						
						tx_id_found = 1;		// return

						SaveTX_ID(neActiveTX_ID);

						break;
					}
				}
			}
		}

		// change the channel
		if (locNeChannel == LAST_CHANNEL)
			locNeChannel = 10;
		else
			++locNeChannel;

	} while (tx_id_found == 0);

	// power down the transceiver
	nRF_CE_lo();
	
	// do one long buzz
	BuzzStart(bindSeq + 4, 1, 0);
	
	// we have to wait before we can switch to TX mode
	_delay_us(130);

	// turn off the LED
	ClrBit(PORT(COPY_TX_ID_LED_PORT), COPY_TX_ID_LED_BIT);
}
