//
// buzzer.h - part of neTX
//
// Author  : Ferenc Szili (kile at the rcgroups.net forum)
// Licence : GNU GPL v3 (see licence.txt)
//

#pragma once

/*
This file contains functions and macros needed by the buzzer driver.
The piezo buzzer has to be internally driven, meaning it has to have it's own
oscillator. The buzzer has to be connected to the OC0A pin of the AVR.
The buzzer is turned on/off with PWM to produce a 'cricket' sound.

The buzzer is dependant on the BuzzDriver() being called from
a 'heartbeat' function

Example:

// set the on/off sequence elements
// these are multiples of 32.768ms on 16MHz
const uint8_t mySeq[] = {5, 5, 10, 15, 40, 20};

BuzzStart(mySeq, 6, 1);		// start buzzing, 6 elements, with looping

*/

extern volatile uint8_t BuzzFlags;	// the flags

// the bits of BuzzFlags
#define BUZZ_FLAG_IS_ON		0
#define BUZZ_FLAG_LOOP		1
#define BUZZ_FLAG_RESET		2

#define IsBuzzOn()		((BuzzFlags & _BV(BUZZ_FLAG_IS_ON)) != 0)

#define IsBuzzLooping()	((BuzzFlags & _BV(BUZZ_FLAG_LOOP)) != 0)

// initilizes the PWM circuitry and the pin the buzzer is connected on
void BuzzInit(void);

// called by the heartbeat interrupt function
void BuzzDriver(void);

// starts the buzzer with the given on/off sequence
void BuzzStart(const uint8_t* seq, const uint8_t seqLen, const uint8_t should_loop);

// stops the buzzer
void BuzzStop(void);

// these turn the looping on/off 
void BuzzLoop(void);
void BuzzOnce(void);
