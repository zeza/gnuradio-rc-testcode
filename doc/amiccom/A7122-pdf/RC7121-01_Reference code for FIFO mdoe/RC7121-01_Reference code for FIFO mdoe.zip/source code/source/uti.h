/********************************************************************
*   UTI.h
*   function Definitions
*
********************************************************************/
#ifndef _UTI_H_
#define _UTI_H_

void delay(void);
void Delay10us(Uint8 n);
void Delay1ms(Uint8 n);
void Delay10ms(Uint8 n);
void Delay100us(Uint8 n);

#endif
